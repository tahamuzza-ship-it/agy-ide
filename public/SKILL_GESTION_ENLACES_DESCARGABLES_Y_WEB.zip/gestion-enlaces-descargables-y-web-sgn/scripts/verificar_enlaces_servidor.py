#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Auditor determinista de enlaces SGN (Web Interactiva vs Descarga Directa)."""
import urllib.request
import hashlib
import sys

def auditar_enlace_web(url: str, fragmento_requerido: str, fragmento_prohibido: str = "") -> bool:
    print(f"[*] Auditando enlace Web Interactivo (No Descargable): {url}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (SGN-Auditor)"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            ct = resp.headers.get("Content-Type", "")
            cd = resp.headers.get("Content-Disposition", "")
            data = resp.read().decode("utf-8", errors="ignore")
            
            if resp.status != 200:
                print(f"  [-] Fallo de estado HTTP: {resp.status}")
                return False
            if "text/html" not in ct:
                print(f"  [-] Advertencia: Content-Type no es text/html ({ct})")
            if cd and "attachment" in cd.lower():
                print(f"  [-] ERROR: El enlace web tiene Content-Disposition attachment! ({cd})")
                return False
            if fragmento_requerido not in data:
                print(f"  [-] ERROR: No se encontró fragmento requerido: '{fragmento_requerido}'")
                return False
            if fragmento_prohibido and fragmento_prohibido in data:
                print(f"  [-] ERROR: Se detectó fragmento prohibido (regresión): '{fragmento_prohibido}'")
                return False
                
            print(f"  [+] ÉXITO: {resp.status} OK | Bytes: {len(data):,} | Visualización en vivo verificada.")
            return True
    except Exception as e:
        print(f"  [-] Excepción al auditar web: {e}")
        return False

def auditar_enlace_descarga(url: str, sha256_esperado: str = "") -> bool:
    print(f"[*] Auditando enlace Descargable (Binario/Attachment): {url}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (SGN-Auditor)"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            cd = resp.headers.get("Content-Disposition", "")
            data = resp.read()
            sha = hashlib.sha256(data).hexdigest()
            
            if resp.status != 200:
                print(f"  [-] Fallo de estado HTTP: {resp.status}")
                return False
            print(f"  [+] Descarga completada: {len(data):,} bytes")
            print(f"  [+] SHA-256 obtenido: {sha}")
            
            if sha256_esperado:
                if sha.lower() == sha256_esperado.lower():
                    print("  [+] SHA-256 verificado: COINCIDENCIA BIT-EXACTA.")
                else:
                    print(f"  [-] ERROR: SHA-256 no coincide. Esperado: {sha256_esperado}")
                    return False
            return True
    except Exception as e:
        print(f"  [-] Excepción al auditar descarga: {e}")
        return False

if __name__ == "__main__":
    url_test = "https://agy-ide-production.up.railway.app/cibercode-manual.html"
    auditar_enlace_web(url_test, "CONSOLA DE APRENDIZAJE", "Volver a AGY IDE")
