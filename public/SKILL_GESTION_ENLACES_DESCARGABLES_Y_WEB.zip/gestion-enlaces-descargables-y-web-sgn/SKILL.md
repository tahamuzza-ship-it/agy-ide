---
name: gestion-enlaces-descargables-y-web-sgn
description: Protocolo, arquitectura y gobernanza de endpoints en el Ecosistema SGN para diferenciar y servir enlaces NO descargables (visualización web interactiva en vivo, consolas didácticas, HTML5/Monaco sin regresión a texto) vs enlaces descargables directos (paquetes ZIP, backups y binarios con Content-Disposition attachment y verificación SHA-256).
version: 1.0.0
author: SGN Multi-Node Sovereign Ecosystem
---

# 🌐 SKILL: GESTIÓN DE ENLACES DESCARGABLES Y NO DESCARGABLES (WEB VS DESCARGA SGN)

## ⚡ 1. PROPÓSITO Y DOCTRINA OPERATIVA
En el Ecosistema SGN (PC1 Bogotá, PC3 Miami, PC4 Supernodo i9 y Railway), existen dos necesidades fundamentales de entrega de información que **NUNCA DEBEN CONFUNDIRSE NI MEZCLARSE**:

1. **ENLACES NO DESCARGABLES (Visualización Web Interactiva en Vivo):**  
   Páginas donde el operador humano o campesino interactúa con botones, Monaco Editor, consolas de aprendizaje, simuladores, calificaciones y autoguardado sin descargar archivos al disco.
2. **ENLACES DESCARGABLES (Distribución Binaria y Paquetes):**  
   Archivos empaquetados (`.zip`, `.json`, `.txt`, `.tar.gz`) que deben guardarse directamente en la carpeta de Descargas del usuario o transferirse entre nodos con certificación criptográfica SHA-256.

> 🛑 **REGLA DE ORO ANTI-REGRESIÓN (BLINDAJE DE CONSOLAS WEB):**  
> Todo artefacto interactivo HTML debe servirse con su propia ruta física independiente (ej. `/cibercode-manual.html`), estrictamente aislada de interceptores, middlewares o scripts dinámicos (como `manual-loader.js` o `/api/manual`) que intenten sobreescribir el DOM del navegador con texto plano o markdown viejo.

---

## 🏛️ 2. MATRIZ DE ARQUITECTURA DE ENLACES

| Atributo | Modalidad A: Enlace NO Descargable (Web Interactiva) | Modalidad B: Enlace Descargable (Descarga Directa) |
| :--- | :--- | :--- |
| **Objetivo** | Ejecutar consola, interactuar, calificar, ver gráficos | Guardar archivo en disco para uso offline o backup |
| **Content-Type** | `text/html; charset=UTF-8` | `application/zip` o `application/octet-stream` |
| **Content-Disposition** | `inline` (o ausente para que el navegador lo renderice) | `attachment; filename="NOMBRE_ARCHIVO.zip"` |
| **Comportamiento en UI** | Abre pestaña en vivo (`target="_blank"`) | Dispara cuadro de guardado o descarga directa |
| **Canal Canónico** | Endpoint Express en `public/` (ej. `/cibercode-manual.html`) | `res.download()` en Railway o `/PAQUETES/` en GitHub |
| **Persistencia** | `localStorage` del navegador (cero pérdida de datos) | Archivo físico en `$HOME\Downloads` |

---

## 💻 3. IMPLEMENTACIÓN TÉCNICA EN EXPRESS / NODE.JS (RAILWAY & AGY IDE)

### A. Configuración de Enlace NO Descargable (Visualización Web en Vivo)
En el servidor Express (`cibercode-relay.cjs` o `server.js`):

```javascript
// 1. Ruta desacoplada e inmune a scripts sobreescribidores
app.get('/cibercode-manual.html', (req, res) => {
  const rutaArchivo = path.join(__dirname, 'public', 'cibercode-manual.html');
  res.setHeader('Content-Type', 'text/html; charset=UTF-8');
  res.setHeader('Content-Disposition', 'inline'); // Fuerza visualización en navegador
  res.sendFile(rutaArchivo);
});
```

En la interfaz de usuario (HTML):
```html
<!-- Botón en la barra superior: abre la consola didáctica en pestaña nueva -->
<a href="/cibercode-manual.html" target="_blank" class="btn-manual-interactivo">
  <span>📖 MANUAL DIDÁCTICO</span>
</a>
```

---

### B. Configuración de Enlace Descargable (Descarga Directa de ZIP)
En el servidor Express:

```javascript
// 2. Ruta de descarga forzada directa (Attachment)
app.get('/descargar-manual.zip', (req, res) => {
  const rutaZip = path.join(__dirname, 'public', 'MANUAL_CIBERCODE_2_SGN.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="MANUAL_CIBERCODE_2_SGN.zip"');
  res.download(rutaZip, 'MANUAL_CIBERCODE_2_SGN.zip', (err) => {
    if (err) console.error("[-] Error en descarga:", err);
  });
});
```

---

## 🚀 4. CANAL ALTERNO GITHUB HUB SGN (`/PAQUETES`)

Para transferir paquetes pesados entre nodos (PC1, PC3 Miami, PC4 i9, PC2 Linux) sin tocar ni saturar Railway:

1. **Ubicación Canónica en Repositorio Oficial:**  
   `https://github.com/Muzzafar-hub/SGN-Arsenal-Agentico/tree/main/PAQUETES`
2. **Descarga en 1 segundo vía PowerShell (PC1, PC3, PC4):**
   ```powershell
   $pkg = "MANUAL_CIBERCODE_2_SGN.zip"
   Invoke-WebRequest -Uri "https://raw.githubusercontent.com/Muzzafar-hub/SGN-Arsenal-Agentico/main/PAQUETES/$pkg" -OutFile "$HOME\Downloads\$pkg"
   (Get-FileHash -Path "$HOME\Downloads\$pkg" -Algorithm SHA256).Hash
   ```
3. **Descarga con 1 Clic Humano en Navegador:**
   El operador humano abre la URL del blob en GitHub y pulsa el botón **Download**.

---

## 🛡️ 5. PROTOCOLO OBLIGATORIO DE PRUEBA PREVIA (REGLA FÁCTICA)
Antes de declarar completada cualquier tarea que involucre enlaces, el agente DEBE ejecutar un script de auditoría automatizado:

1. Solicitar la URL web y verificar:
   * `status_code == 200`
   * `Content-Type` contiene `text/html`
   * `Content-Length > 5000` (no es una plantilla vacía o error 404 camuflado).
   * Verificación semántica: Confirmar que el contenido contiene los elementos clave (ej. tarjetas de prueba, botones) y **NO contiene mensajes de error de recarga**.
2. Solicitar la URL de descarga y verificar:
   * `status_code == 200`
   * `Content-Disposition` contiene `attachment`
   * SHA-256 del binario coincide exactamente con el archivo original en local.

---
*Aprobado bajo la Constitución Maestra SGN — Versión Multi-Nodo 2026.*
